# Dlavie WhatsApp Cloud API Bot

Bot WhatsApp resmi untuk Dlavie Commerce menggunakan **WhatsApp Cloud API**, bukan pairing-code/Baileys/WhatsApp Web automation.

Fitur utama:

- Webhook resmi Meta untuk menerima pesan WhatsApp.
- Signature verification `x-hub-signature-256`.
- AI intent classification untuk chat/CS.
- Product search.
- Cart.
- Checkout via API website Dlavie.
- Human handoff ke CS.
- Admin API untuk sesi, handoff, reset, dan kirim pesan manual.
- Mock commerce mode agar bisa langsung dites tanpa backend website.

---

## 1. Requirement

- Node.js 20+
- Akun Meta Developer
- WhatsApp Business Account
- WhatsApp Cloud API phone number
- HTTPS public URL untuk webhook, contoh: VPS, Railway, Render, Fly.io, atau ngrok untuk development

---

## 2. Install

```bash
npm install
cp .env.example .env
npm run dev
```

Health check:

```bash
curl http://localhost:3000/admin/health
```

---

## 3. Environment

Edit `.env`:

```env
PORT=3000
PUBLIC_BASE_URL=https://your-domain.com

WA_GRAPH_VERSION=v22.0
WA_PHONE_NUMBER_ID=your_phone_number_id
WA_ACCESS_TOKEN=your_permanent_access_token
WA_VERIFY_TOKEN=make_a_long_random_verify_token
META_APP_SECRET=your_meta_app_secret

OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4.1-mini

MOCK_COMMERCE=true
DLAVIE_API_BASE_URL=https://dlavie-commerce.com
DLAVIE_API_TOKEN=your_internal_api_token
CHECKOUT_BASE_URL=https://dlavie-commerce.com/checkout

ADMIN_TOKEN=make_a_long_random_admin_token
```

> Untuk testing awal, biarkan `MOCK_COMMERCE=true`. Setelah website Dlavie siap, ubah ke `MOCK_COMMERCE=false`.

---

## 4. Setup WhatsApp Cloud API di Meta

1. Buka Meta Developer Console.
2. Buat App.
3. Tambahkan produk **WhatsApp**.
4. Ambil:
   - Phone Number ID
   - Access Token
   - App Secret
5. Deploy server ini ke domain HTTPS.
6. Set webhook callback URL:

```txt
https://your-domain.com/webhook/whatsapp
```

7. Set Verify Token sama dengan `WA_VERIFY_TOKEN` di `.env`.
8. Subscribe field: `messages`.
9. Test kirim pesan ke nomor WhatsApp Cloud API.

---

## 5. Endpoint webhook

### Verify webhook

```http
GET /webhook/whatsapp
```

Dipanggil oleh Meta saat setup webhook.

### Receive incoming message

```http
POST /webhook/whatsapp
```

Dipanggil oleh Meta saat customer mengirim pesan atau menekan interactive message.

---

## 6. Flow chat yang sudah tersedia

Customer bisa mengetik:

```txt
halo
cari produk
cari hoodie
beli nomor 1
keranjang
checkout
cs
reset
```

Flow checkout:

```txt
User: checkout
Bot: minta nama
User: Darma
Bot: minta alamat
User: alamat lengkap
Bot: konfirmasi order
User: YA
Bot: buat order + kirim payment link
```

---

## 7. Integrasi dengan Website Dlavie Commerce

Saat `MOCK_COMMERCE=false`, website Dlavie harus menyediakan endpoint internal berikut.

### Search products

```http
GET /api/bot/products?search=hoodie
Authorization: Bearer <DLAVIE_API_TOKEN>
```

Response:

```json
{
  "items": [
    {
      "id": "prd_001",
      "name": "Dlavie Hoodie Black",
      "price": 199000,
      "stock": 12,
      "description": "Hoodie hitam premium"
    }
  ]
}
```

### Get product detail

```http
GET /api/bot/products/prd_001
Authorization: Bearer <DLAVIE_API_TOKEN>
```

Response:

```json
{
  "id": "prd_001",
  "name": "Dlavie Hoodie Black",
  "price": 199000,
  "stock": 12
}
```

### Create order

```http
POST /api/bot/orders
Authorization: Bearer <DLAVIE_API_TOKEN>
Content-Type: application/json
```

Request:

```json
{
  "channel": "whatsapp",
  "waNumber": "6281234567890",
  "customerName": "Darma",
  "address": "Alamat lengkap",
  "items": [
    {
      "productId": "prd_001",
      "name": "Dlavie Hoodie Black",
      "price": 199000,
      "quantity": 1
    }
  ],
  "note": ""
}
```

Response:

```json
{
  "orderNumber": "DLV-20260523-001",
  "total": 199000,
  "status": "pending_payment",
  "paymentUrl": "https://dlavie-commerce.com/checkout/DLV-20260523-001"
}
```

Important: website backend harus menghitung ulang harga, diskon, stok, ongkir, dan total. Jangan percaya angka dari WhatsApp bot.

---

## 8. Admin API

Semua endpoint admin selain health butuh header:

```http
x-admin-token: <ADMIN_TOKEN>
```

### List sessions

```bash
curl http://localhost:3000/admin/sessions \
  -H "x-admin-token: $ADMIN_TOKEN"
```

### Enable/disable human handoff

```bash
curl -X POST http://localhost:3000/admin/sessions/6281234567890/handoff \
  -H "Content-Type: application/json" \
  -H "x-admin-token: $ADMIN_TOKEN" \
  -d '{"enabled":false}'
```

### Reset session

```bash
curl -X POST http://localhost:3000/admin/sessions/6281234567890/reset \
  -H "x-admin-token: $ADMIN_TOKEN"
```

### Send manual text

```bash
curl -X POST http://localhost:3000/admin/send-text \
  -H "Content-Type: application/json" \
  -H "x-admin-token: $ADMIN_TOKEN" \
  -d '{"to":"6281234567890","text":"Halo dari CS Dlavie."}'
```

---

## 9. Production checklist

- Gunakan HTTPS valid.
- Set `NODE_ENV=production`.
- Isi `META_APP_SECRET` dan jangan disable signature verification.
- Ganti in-memory session ke Redis/PostgreSQL.
- Simpan `messages`, `customers`, `carts`, dan `orders` ke database.
- Tambahkan rate limit per nomor WhatsApp.
- Gunakan token permanent dari Meta System User, bukan temporary token.
- Buat template message resmi untuk follow-up di luar customer service window.
- Siapkan dashboard CS manusia untuk human takeover.
- Jangan mengirim spam/broadcast tanpa opt-in dan template yang disetujui.

---

## 10. Catatan kebijakan platform

Bot ini dirancang untuk use case Dlavie Commerce: customer service, product discovery, dan checkout. Jangan jadikan bot sebagai general-purpose chatbot bebas di WhatsApp. Pertahankan konteks pada layanan Dlavie, produk, order, pembayaran, retur, dan bantuan pelanggan.
