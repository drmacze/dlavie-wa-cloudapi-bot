import express from "express";
import pinoHttp from "pino-http";
import { adminRouter } from "./routes/admin.routes.js";
import { webhookRouter } from "./routes/webhook.routes.js";
import { logger } from "./utils/logger.js";

export function createServer() {
  const app = express();

  app.use(pinoHttp({ logger }));

  app.use(
    express.json({
      limit: "1mb",
      verify: (req, res, buf) => {
        req.rawBody = buf;
      }
    })
  );

  app.get("/", (req, res) => {
    res.json({
      ok: true,
      service: "Dlavie WhatsApp Cloud API Bot",
      docs: "/admin/health"
    });
  });

  app.use("/webhook", webhookRouter);
  app.use("/admin", adminRouter);

  app.use((err, req, res, next) => {
    logger.error({ err }, "Unhandled server error");
    res.status(500).json({ ok: false, error: "Internal server error" });
  });

  return app;
}
