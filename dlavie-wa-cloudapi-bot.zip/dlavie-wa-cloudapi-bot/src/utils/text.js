export function normalizeText(value = "") {
  return String(value).trim().replace(/\s+/g, " ");
}

export function normalizeLower(value = "") {
  return normalizeText(value).toLowerCase();
}

export function formatRupiah(value = 0) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

export function safeSlice(text, max = 3900) {
  const value = String(text || "");
  if (value.length <= max) return value;
  return `${value.slice(0, max - 1)}…`;
}

export function extractSelectedNumber(text = "") {
  const match = String(text).match(/(?:nomor|no|pilih|beli)?\s*(\d{1,2})/i);
  if (!match) return null;
  const number = Number(match[1]);
  return Number.isFinite(number) ? number : null;
}

export function parseQuantity(text = "") {
  const match = String(text).match(/(?:x|qty|jumlah|sebanyak)?\s*(\d{1,3})\s*(?:pcs|pc|buah|item)?/i);
  if (!match) return 1;
  const quantity = Number(match[1]);
  if (!Number.isFinite(quantity) || quantity < 1) return 1;
  return Math.min(quantity, 99);
}
