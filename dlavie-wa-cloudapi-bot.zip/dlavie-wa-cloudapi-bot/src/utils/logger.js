import pino from "pino";

export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  redact: [
    "req.headers.authorization",
    "req.headers.x-admin-token",
    "WA_ACCESS_TOKEN",
    "OPENAI_API_KEY",
    "DLAVIE_API_TOKEN"
  ]
});
