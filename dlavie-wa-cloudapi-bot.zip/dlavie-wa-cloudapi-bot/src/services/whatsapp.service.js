import { env } from "../config/env.js";
import { safeSlice } from "../utils/text.js";

function whatsappEndpoint() {
  return `https://graph.facebook.com/${env.waGraphVersion}/${env.waPhoneNumberId}/messages`;
}

async function sendPayload(payload) {
  if (!env.waAccessToken || !env.waPhoneNumberId) {
    throw new Error("WhatsApp Cloud API credentials are not configured");
  }

  const response = await fetch(whatsappEndpoint(), {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.waAccessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      ...payload
    })
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(`WhatsApp send failed: ${response.status} ${JSON.stringify(data)}`);
  }

  return data;
}

export async function sendText(to, body) {
  return sendPayload({
    to,
    type: "text",
    text: {
      preview_url: false,
      body: safeSlice(body)
    }
  });
}

export async function sendButtons(to, body, buttons) {
  const safeButtons = buttons.slice(0, 3).map((button, index) => ({
    type: "reply",
    reply: {
      id: button.id || `btn_${index + 1}`,
      title: String(button.title).slice(0, 20)
    }
  }));

  return sendPayload({
    to,
    type: "interactive",
    interactive: {
      type: "button",
      body: {
        text: safeSlice(body, 1024)
      },
      action: {
        buttons: safeButtons
      }
    }
  });
}

export async function sendList(to, body, rows, buttonText = "Pilih") {
  const safeRows = rows.slice(0, 10).map((row, index) => ({
    id: row.id || `row_${index + 1}`,
    title: String(row.title).slice(0, 24),
    description: String(row.description || "").slice(0, 72)
  }));

  return sendPayload({
    to,
    type: "interactive",
    interactive: {
      type: "list",
      body: {
        text: safeSlice(body, 1024)
      },
      action: {
        button: String(buttonText).slice(0, 20),
        sections: [
          {
            title: "Produk Dlavie",
            rows: safeRows
          }
        ]
      }
    }
  });
}
