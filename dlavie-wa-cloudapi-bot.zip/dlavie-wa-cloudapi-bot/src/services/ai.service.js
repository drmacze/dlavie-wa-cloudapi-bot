import { env } from "../config/env.js";
import { normalizeLower } from "../utils/text.js";

const INTENT_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["intent", "query", "productNumber", "productId", "quantity", "reply"],
  properties: {
    intent: {
      type: "string",
      enum: [
        "greeting",
        "product_search",
        "add_to_cart",
        "show_cart",
        "checkout",
        "faq",
        "handoff_cs",
        "reset"
      ]
    },
    query: { type: ["string", "null"] },
    productNumber: { type: ["number", "null"] },
    productId: { type: ["string", "null"] },
    quantity: { type: ["number", "null"] },
    reply: { type: "string" }
  }
};

const SYSTEM_INSTRUCTIONS = `
Kamu adalah AI assistant resmi untuk Dlavie Commerce.

Tugas utama:
- Klasifikasikan pesan customer untuk membantu alur commerce WhatsApp.
- Jawab dengan ramah, singkat, jelas, dan profesional dalam bahasa Indonesia.
- Jangan mengarang harga, stok, promo, order, resi, atau estimasi pengiriman.
- Untuk pembelian, arahkan ke intent commerce agar sistem backend yang memproses.
- Jika customer marah, meminta admin, komplain, refund, retur, atau kasus sensitif, gunakan intent handoff_cs.
- Jika user meminta reset percakapan/keranjang, gunakan intent reset.

Contoh:
"halo" => greeting
"cari hoodie hitam" => product_search, query hoodie hitam
"beli nomor 1 dua pcs" => add_to_cart, productNumber 1, quantity 2
"keranjang" => show_cart
"checkout" => checkout
"admin" => handoff_cs
`;

export async function classifyMessage(message) {
  const fallback = fallbackClassify(message);

  if (!env.openaiApiKey) {
    return fallback;
  }

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.openaiApiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: env.openaiModel,
        instructions: SYSTEM_INSTRUCTIONS,
        input: message,
        temperature: 0.2,
        max_output_tokens: 500,
        text: {
          format: {
            type: "json_schema",
            name: "dlavie_whatsapp_intent",
            strict: true,
            schema: INTENT_SCHEMA
          }
        }
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("OpenAI classify error:", data);
      return fallback;
    }

    const text = extractOutputText(data);
    return { ...fallback, ...JSON.parse(text) };
  } catch (error) {
    console.error("AI classify fallback:", error.message);
    return fallback;
  }
}

export async function generateFaqReply(message, context = "") {
  const fallback = "Aku bisa bantu info produk, cara order, checkout, atau menghubungkan kamu ke CS Dlavie. Untuk mulai, ketik: cari produk.";

  if (!env.openaiApiKey) return fallback;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.openaiApiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: env.openaiModel,
        instructions: `
Kamu adalah CS Dlavie Commerce.
Jawab dalam bahasa Indonesia yang ramah, ringkas, dan profesional.
Jangan mengarang stok, harga, promo, nomor resi, atau status order.
Jika butuh admin manusia, minta customer ketik "CS".
Konteks sistem:
${context || "-"}
`,
        input: message,
        temperature: 0.3,
        max_output_tokens: 600
      })
    });

    const data = await response.json();
    if (!response.ok) return fallback;

    return extractOutputText(data) || fallback;
  } catch {
    return fallback;
  }
}

function extractOutputText(response) {
  if (response.output_text) return response.output_text;

  const output = response.output || [];
  for (const item of output) {
    const content = item.content || [];
    for (const part of content) {
      if (part.type === "output_text" && part.text) return part.text;
    }
  }

  return "";
}

function fallbackClassify(message) {
  const text = normalizeLower(message);

  if (!text) {
    return base("faq", "");
  }

  if (["halo", "hai", "hi", "p", "assalamualaikum", "selamat pagi", "selamat siang"].some((word) => text.includes(word))) {
    return base("greeting", null, "Halo, selamat datang di Dlavie Commerce ✨");
  }

  if (["cs", "admin", "customer service", "komplain", "refund", "retur", "return"].some((word) => text.includes(word))) {
    return base("handoff_cs", null, "Baik, aku hubungkan ke CS Dlavie ya.");
  }

  if (["reset", "ulang", "hapus keranjang", "batalkan"].some((word) => text.includes(word))) {
    return base("reset", null, "Percakapan direset.");
  }

  if (["keranjang", "cart", "troli"].some((word) => text.includes(word))) {
    return base("show_cart", null, "Ini keranjang kamu.");
  }

  if (["checkout", "bayar", "lanjut pembayaran"].some((word) => text.includes(word))) {
    return base("checkout", null, "Baik, kita lanjut checkout.");
  }

  if (["beli", "ambil", "pesan", "order"].some((word) => text.includes(word))) {
    const productNumber = Number(text.match(/\d+/)?.[0] || 1);
    return {
      ...base("add_to_cart", null, "Produk akan ditambahkan ke keranjang."),
      productNumber: Number.isFinite(productNumber) ? productNumber : 1,
      quantity: 1
    };
  }

  if (["cari", "produk", "ada", "jual", "hoodie", "kaos", "tote", "topi"].some((word) => text.includes(word))) {
    const query = text.replace(/\b(cari|produk|ada|jual|mau|dong|kak|ka)\b/g, "").trim();
    return base("product_search", query || text, "Aku carikan produknya ya.");
  }

  return base("faq", null, "Aku bantu jawab ya.");
}

function base(intent, query = null, reply = "") {
  return {
    intent,
    query,
    productNumber: null,
    productId: null,
    quantity: null,
    reply
  };
}
