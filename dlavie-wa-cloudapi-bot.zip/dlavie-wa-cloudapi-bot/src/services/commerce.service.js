import { env } from "../config/env.js";
import { mockProducts } from "./mock-catalog.js";

async function dlavieFetch(path, options = {}) {
  if (!env.dlavieApiBaseUrl) {
    throw new Error("DLAVIE_API_BASE_URL is not configured");
  }

  const response = await fetch(`${env.dlavieApiBaseUrl}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.dlavieApiToken}`,
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(`Dlavie API failed: ${response.status} ${JSON.stringify(data)}`);
  }

  return data;
}

export async function searchProducts(query = "") {
  if (env.mockCommerce) {
    const normalized = query.toLowerCase();
    const items = mockProducts.filter((product) => {
      const haystack = `${product.name} ${product.category} ${product.description}`.toLowerCase();
      return !normalized || haystack.includes(normalized);
    });

    return { items: items.length ? items : mockProducts };
  }

  const params = new URLSearchParams({ search: query });
  return dlavieFetch(`/api/bot/products?${params.toString()}`);
}

export async function getProduct(productId) {
  if (env.mockCommerce) {
    return mockProducts.find((product) => product.id === productId) || null;
  }

  return dlavieFetch(`/api/bot/products/${encodeURIComponent(productId)}`);
}

export async function createOrder({ waNumber, customerName, address, items, note = "" }) {
  if (env.mockCommerce) {
    const total = items.reduce((sum, item) => sum + Number(item.price) * Number(item.quantity), 0);
    const orderNumber = `DLV-${Date.now().toString().slice(-8)}`;
    const baseUrl = env.checkoutBaseUrl || "https://dlavie-commerce.com/checkout";

    return {
      orderNumber,
      total,
      status: "pending_payment",
      paymentUrl: `${baseUrl}/${orderNumber}`,
      customerName,
      address,
      waNumber,
      note
    };
  }

  return dlavieFetch("/api/bot/orders", {
    method: "POST",
    body: JSON.stringify({
      channel: "whatsapp",
      waNumber,
      customerName,
      address,
      items,
      note
    })
  });
}
