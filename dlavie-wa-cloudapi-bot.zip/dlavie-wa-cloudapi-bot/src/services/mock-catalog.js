export const mockProducts = [
  {
    id: "dlv-hoodie-black",
    name: "Dlavie Hoodie Black",
    price: 199000,
    stock: 12,
    category: "fashion",
    description: "Hoodie hitam premium dengan cutting relaxed fit."
  },
  {
    id: "dlv-tee-white",
    name: "Dlavie Essential Tee White",
    price: 89000,
    stock: 24,
    category: "fashion",
    description: "Kaos basic putih cotton combed, nyaman untuk harian."
  },
  {
    id: "dlv-tote-cream",
    name: "Dlavie Tote Bag Cream",
    price: 59000,
    stock: 18,
    category: "accessory",
    description: "Tote bag canvas warna cream, cocok untuk daily carry."
  },
  {
    id: "dlv-cap-black",
    name: "Dlavie Signature Cap Black",
    price: 79000,
    stock: 9,
    category: "accessory",
    description: "Topi signature Dlavie dengan strap adjustable."
  }
];
