import { classifyMessage, generateFaqReply } from "./ai.service.js";
import { createOrder, getProduct, searchProducts } from "./commerce.service.js";
import { sendButtons, sendList, sendText } from "./whatsapp.service.js";
import { getSession, resetSession, updateSession } from "../store/session.store.js";
import { extractSelectedNumber, formatRupiah, normalizeLower, normalizeText, parseQuantity } from "../utils/text.js";

export async function processIncomingText({ waNumber, text }) {
  const cleanText = normalizeText(text);
  const lower = normalizeLower(cleanText);
  const session = getSession(waNumber);

  if (session.humanTakeover) {
    return;
  }

  if (session.checkout.step) {
    return processCheckoutStep({ waNumber, text: cleanText });
  }

  const ai = await classifyMessage(cleanText);

  switch (ai.intent) {
    case "greeting":
      return sendGreeting(waNumber);

    case "product_search":
      return handleProductSearch(waNumber, ai.query || cleanText);

    case "add_to_cart":
      return handleAddToCart(waNumber, {
        productNumber: ai.productNumber || extractSelectedNumber(cleanText),
        productId: ai.productId,
        quantity: ai.quantity || parseQuantity(cleanText)
      });

    case "show_cart":
      return sendCart(waNumber);

    case "checkout":
      return startCheckout(waNumber);

    case "handoff_cs":
      return handoffToCs(waNumber);

    case "reset":
      resetSession(waNumber);
      return sendText(waNumber, "Percakapan dan keranjang kamu sudah direset. Ketik `cari produk` untuk mulai lagi ya ✨");

    case "faq":
    default: {
      // Useful shortcut when fallback AI is uncertain but user typed explicit product words.
      if (lower.includes("cari produk") || lower === "produk") {
        return handleProductSearch(waNumber, "");
      }

      const reply = await generateFaqReply(cleanText);
      return sendText(waNumber, reply);
    }
  }
}

export async function processInteractiveReply({ waNumber, id, title }) {
  const text = title || id || "";

  if (id?.startsWith("product:")) {
    const productId = id.split(":")[1];
    return handleAddToCart(waNumber, { productId, quantity: 1 });
  }

  if (id === "search:products") return handleProductSearch(waNumber, "");
  if (id === "cart:view") return sendCart(waNumber);
  if (id === "checkout:start") return startCheckout(waNumber);
  if (id === "checkout:confirm") return processCheckoutStep({ waNumber, text: "YA" });
  if (id === "cs:handoff") return handoffToCs(waNumber);

  return processIncomingText({ waNumber, text });
}

async function sendGreeting(waNumber) {
  return sendButtons(
    waNumber,
    "Halo, selamat datang di Dlavie Commerce ✨\n\nAku bisa bantu cari produk, jawab pertanyaan, checkout, atau hubungkan kamu ke CS.",
    [
      { id: "search:products", title: "Cari Produk" },
      { id: "cart:view", title: "Keranjang" },
      { id: "cs:handoff", title: "CS" }
    ]
  );
}

async function handleProductSearch(waNumber, query) {
  const result = await searchProducts(query);
  const products = Array.isArray(result) ? result : result.items || [];

  updateSession(waNumber, (session) => {
    session.lastProducts = products.slice(0, 10);
  });

  if (!products.length) {
    return sendText(waNumber, `Maaf, aku belum menemukan produk untuk "${query}". Coba keyword lain ya.`);
  }

  const rows = products.slice(0, 10).map((product) => ({
    id: `product:${product.id}`,
    title: product.name,
    description: `${formatRupiah(product.price)} • Stok ${product.stock ?? "-"}`
  }));

  const summary = products
    .slice(0, 5)
    .map((product, index) => `${index + 1}. ${product.name} — ${formatRupiah(product.price)}\n   Stok: ${product.stock ?? "-"}`)
    .join("\n\n");

  try {
    return sendList(waNumber, `Aku menemukan produk ini:\n\n${summary}\n\nPilih produk di bawah atau ketik: beli nomor 1`, rows, "Pilih Produk");
  } catch {
    return sendText(waNumber, `Aku menemukan produk ini:\n\n${summary}\n\nUntuk beli, ketik: beli nomor 1`);
  }
}

async function handleAddToCart(waNumber, { productNumber, productId, quantity = 1 }) {
  const session = getSession(waNumber);
  let product = null;

  if (productId) {
    product = await getProduct(productId);
  }

  if (!product && productNumber) {
    product = session.lastProducts[Number(productNumber) - 1];
  }

  if (!product) {
    return sendText(waNumber, "Produknya belum jelas. Coba ketik `cari produk`, lalu pilih dari daftar produk yang muncul.");
  }

  const freshProduct = await getProduct(product.id);
  const finalProduct = freshProduct || product;

  if (Number(finalProduct.stock || 0) < Number(quantity)) {
    return sendText(waNumber, `Maaf, stok ${finalProduct.name} tidak cukup. Stok tersedia: ${finalProduct.stock || 0}.`);
  }

  updateSession(waNumber, (session) => {
    const existing = session.cart.find((item) => item.productId === finalProduct.id);

    if (existing) {
      existing.quantity += Number(quantity);
      existing.price = Number(finalProduct.price);
      existing.name = finalProduct.name;
    } else {
      session.cart.push({
        productId: finalProduct.id,
        name: finalProduct.name,
        price: Number(finalProduct.price),
        quantity: Number(quantity)
      });
    }
  });

  return sendButtons(
    waNumber,
    `${finalProduct.name} x${quantity} sudah masuk keranjang 🛒\n\nKetik \"checkout\" untuk lanjut pembayaran atau cari produk lain.`,
    [
      { id: "cart:view", title: "Keranjang" },
      { id: "checkout:start", title: "Checkout" },
      { id: "search:products", title: "Cari Lagi" }
    ]
  );
}

async function sendCart(waNumber) {
  const session = getSession(waNumber);

  if (!session.cart.length) {
    return sendText(waNumber, "Keranjang kamu masih kosong. Ketik `cari produk` untuk mulai belanja ya.");
  }

  const lines = session.cart.map((item, index) => {
    const subtotal = item.price * item.quantity;
    return `${index + 1}. ${item.name}\n   ${item.quantity} x ${formatRupiah(item.price)} = ${formatRupiah(subtotal)}`;
  });

  const total = session.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return sendButtons(
    waNumber,
    `Keranjang kamu:\n\n${lines.join("\n\n")}\n\nTotal sementara: ${formatRupiah(total)}`,
    [
      { id: "checkout:start", title: "Checkout" },
      { id: "search:products", title: "Cari Lagi" },
      { id: "cs:handoff", title: "CS" }
    ]
  );
}

async function startCheckout(waNumber) {
  const session = getSession(waNumber);

  if (!session.cart.length) {
    return sendText(waNumber, "Keranjang kamu masih kosong. Ketik `cari produk` untuk mulai belanja.");
  }

  updateSession(waNumber, (session) => {
    session.checkout.step = "name";
  });

  return sendText(waNumber, "Baik, kita lanjut checkout. Tulis nama penerima terlebih dahulu ya.");
}

async function processCheckoutStep({ waNumber, text }) {
  const session = getSession(waNumber);

  if (normalizeLower(text) === "batal" || normalizeLower(text) === "cancel") {
    updateSession(waNumber, (session) => {
      session.checkout = { step: null, customerName: null, address: null, note: null };
    });
    return sendText(waNumber, "Checkout dibatalkan. Keranjang kamu masih tersimpan.");
  }

  if (session.checkout.step === "name") {
    updateSession(waNumber, (session) => {
      session.checkout.customerName = text;
      session.checkout.step = "address";
    });

    return sendText(waNumber, "Terima kasih. Sekarang tulis alamat lengkap pengiriman ya, termasuk kecamatan/kota dan kode pos jika ada.");
  }

  if (session.checkout.step === "address") {
    updateSession(waNumber, (session) => {
      session.checkout.address = text;
      session.checkout.step = "confirm";
    });

    return sendCheckoutConfirmation(waNumber);
  }

  if (session.checkout.step === "confirm") {
    const lower = normalizeLower(text);

    if (!["ya", "y", "yes", "oke", "ok", "lanjut", "konfirmasi"].includes(lower)) {
      return sendText(waNumber, "Ketik `YA` untuk konfirmasi order, atau `batal` untuk membatalkan checkout.");
    }

    return finalizeCheckout(waNumber);
  }
}

async function sendCheckoutConfirmation(waNumber) {
  const session = getSession(waNumber);
  const total = session.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const items = session.cart.map((item) => `- ${item.name} x${item.quantity}`).join("\n");

  return sendButtons(
    waNumber,
    `Konfirmasi order:\n\nNama: ${session.checkout.customerName}\nAlamat: ${session.checkout.address}\n\nItem:\n${items}\n\nTotal sementara: ${formatRupiah(total)}\n\nKetik YA untuk membuat order.`,
    [
      { id: "checkout:confirm", title: "YA" },
      { id: "cs:handoff", title: "CS" }
    ]
  );
}

async function finalizeCheckout(waNumber) {
  const session = getSession(waNumber);

  const order = await createOrder({
    waNumber,
    customerName: session.checkout.customerName,
    address: session.checkout.address,
    items: session.cart
  });

  resetSession(waNumber);

  return sendText(
    waNumber,
    `Order berhasil dibuat 🎉\n\nNomor order: ${order.orderNumber}\nTotal: ${formatRupiah(order.total)}\nStatus: ${order.status || "pending_payment"}\n\nLink pembayaran:\n${order.paymentUrl}\n\nSetelah pembayaran berhasil, pesanan akan diproses oleh tim Dlavie.`
  );
}

async function handoffToCs(waNumber) {
  updateSession(waNumber, (session) => {
    session.humanTakeover = true;
  });

  return sendText(waNumber, "Baik, aku hubungkan ke CS Dlavie ya. Tim kami akan membantu kamu secepatnya 🙏");
}
