import { env, validateEnv } from "./config/env.js";
import { createServer } from "./server.js";
import { logger } from "./utils/logger.js";

validateEnv();

const app = createServer();

app.listen(env.port, () => {
  logger.info(`Dlavie WhatsApp Cloud API Bot running on port ${env.port}`);
});
