import { env } from "../config/env.js";

export function adminAuth(req, res, next) {
  const token = req.get("x-admin-token");

  if (!env.adminToken || token !== env.adminToken) {
    return res.status(401).json({
      ok: false,
      error: "Unauthorized admin request"
    });
  }

  next();
}
