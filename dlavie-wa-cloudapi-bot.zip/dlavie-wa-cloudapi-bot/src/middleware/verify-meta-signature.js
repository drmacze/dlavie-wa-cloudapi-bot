import crypto from "crypto";
import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";

export function verifyMetaSignature(req, res, next) {
  if (env.nodeEnv !== "production" && !env.metaAppSecret) {
    return next();
  }

  const signature = req.get("x-hub-signature-256");
  if (!signature || !signature.startsWith("sha256=")) {
    logger.warn("Missing or invalid Meta signature header");
    return res.sendStatus(401);
  }

  const expected =
    "sha256=" +
    crypto
      .createHmac("sha256", env.metaAppSecret)
      .update(req.rawBody || Buffer.from(JSON.stringify(req.body || {})))
      .digest("hex");

  const receivedBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);

  if (receivedBuffer.length !== expectedBuffer.length) {
    return res.sendStatus(401);
  }

  const valid = crypto.timingSafeEqual(receivedBuffer, expectedBuffer);
  if (!valid) {
    logger.warn("Invalid Meta webhook signature");
    return res.sendStatus(401);
  }

  next();
}
