import express from "express";
import { env } from "../config/env.js";
import { verifyMetaSignature } from "../middleware/verify-meta-signature.js";
import { processIncomingText, processInteractiveReply } from "../services/bot.service.js";
import { hasProcessedMessage, markMessageProcessed } from "../store/session.store.js";
import { logger } from "../utils/logger.js";

export const webhookRouter = express.Router();

webhookRouter.get("/whatsapp", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === env.waVerifyToken) {
    return res.status(200).send(challenge);
  }

  return res.sendStatus(403);
});

webhookRouter.post("/whatsapp", verifyMetaSignature, async (req, res) => {
  // Meta expects a quick 200. We acknowledge first, then process.
  res.sendStatus(200);

  try {
    const messages = extractMessages(req.body);

    for (const message of messages) {
      await handleMessage(message);
    }
  } catch (error) {
    logger.error({ error }, "Failed to process WhatsApp webhook");
  }
});

async function handleMessage(message) {
  if (!message?.id || !message?.from) return;
  if (hasProcessedMessage(message.id)) return;

  markMessageProcessed(message.id);

  const waNumber = message.from;

  if (message.type === "text") {
    const text = message.text?.body || "";
    await processIncomingText({ waNumber, text });
    return;
  }

  if (message.type === "interactive") {
    const button = message.interactive?.button_reply;
    const list = message.interactive?.list_reply;

    await processInteractiveReply({
      waNumber,
      id: button?.id || list?.id,
      title: button?.title || list?.title
    });
  }
}

function extractMessages(payload) {
  const messages = [];

  for (const entry of payload.entry || []) {
    for (const change of entry.changes || []) {
      const value = change.value || {};
      for (const message of value.messages || []) {
        messages.push(message);
      }
    }
  }

  return messages;
}
