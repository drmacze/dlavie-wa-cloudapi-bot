import express from "express";
import { adminAuth } from "../middleware/admin-auth.js";
import { sendText } from "../services/whatsapp.service.js";
import { getSession, listSessions, resetSession, updateSession } from "../store/session.store.js";

export const adminRouter = express.Router();

adminRouter.get("/health", (req, res) => {
  res.json({
    ok: true,
    service: "dlavie-wa-cloudapi-bot",
    time: new Date().toISOString()
  });
});

adminRouter.use(adminAuth);

adminRouter.get("/sessions", (req, res) => {
  res.json({ ok: true, sessions: listSessions() });
});

adminRouter.get("/sessions/:waNumber", (req, res) => {
  res.json({ ok: true, session: getSession(req.params.waNumber) });
});

adminRouter.post("/sessions/:waNumber/handoff", (req, res) => {
  const enabled = Boolean(req.body?.enabled);

  const session = updateSession(req.params.waNumber, (session) => {
    session.humanTakeover = enabled;
  });

  res.json({ ok: true, session });
});

adminRouter.post("/sessions/:waNumber/reset", (req, res) => {
  const session = resetSession(req.params.waNumber);
  res.json({ ok: true, session });
});

adminRouter.post("/send-text", async (req, res) => {
  const { to, text } = req.body || {};

  if (!to || !text) {
    return res.status(400).json({ ok: false, error: "Fields to and text are required" });
  }

  const result = await sendText(to, text);
  res.json({ ok: true, result });
});
