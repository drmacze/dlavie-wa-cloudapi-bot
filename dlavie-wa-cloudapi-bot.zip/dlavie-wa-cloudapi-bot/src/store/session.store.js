const sessions = new Map();
const processedMessageIds = new Set();

export function hasProcessedMessage(messageId) {
  return processedMessageIds.has(messageId);
}

export function markMessageProcessed(messageId) {
  processedMessageIds.add(messageId);

  // Simple memory guard for MVP. Use Redis/PostgreSQL in production.
  if (processedMessageIds.size > 10000) {
    const first = processedMessageIds.values().next().value;
    processedMessageIds.delete(first);
  }
}

export function getSession(waNumber) {
  if (!sessions.has(waNumber)) {
    sessions.set(waNumber, createEmptySession());
  }

  return sessions.get(waNumber);
}

export function createEmptySession() {
  return {
    cart: [],
    lastProducts: [],
    checkout: {
      step: null,
      customerName: null,
      address: null,
      note: null
    },
    humanTakeover: false,
    previousResponseId: null,
    updatedAt: new Date().toISOString()
  };
}

export function updateSession(waNumber, updater) {
  const session = getSession(waNumber);
  updater(session);
  session.updatedAt = new Date().toISOString();
  return session;
}

export function resetSession(waNumber) {
  const fresh = createEmptySession();
  sessions.set(waNumber, fresh);
  return fresh;
}

export function listSessions() {
  return Array.from(sessions.entries()).map(([waNumber, session]) => ({
    waNumber,
    cartCount: session.cart.length,
    humanTakeover: session.humanTakeover,
    checkoutStep: session.checkout.step,
    updatedAt: session.updatedAt
  }));
}
