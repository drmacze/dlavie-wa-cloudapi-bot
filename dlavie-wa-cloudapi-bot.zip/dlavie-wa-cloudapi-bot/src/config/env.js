import dotenv from "dotenv";

dotenv.config();

const requiredInProduction = [
  "WA_GRAPH_VERSION",
  "WA_PHONE_NUMBER_ID",
  "WA_ACCESS_TOKEN",
  "WA_VERIFY_TOKEN",
  "META_APP_SECRET",
  "ADMIN_TOKEN"
];

export const env = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: Number(process.env.PORT || 3000),
  publicBaseUrl: process.env.PUBLIC_BASE_URL || "http://localhost:3000",

  waGraphVersion: process.env.WA_GRAPH_VERSION || "v22.0",
  waPhoneNumberId: process.env.WA_PHONE_NUMBER_ID || "",
  waAccessToken: process.env.WA_ACCESS_TOKEN || "",
  waVerifyToken: process.env.WA_VERIFY_TOKEN || "",
  metaAppSecret: process.env.META_APP_SECRET || "",

  openaiApiKey: process.env.OPENAI_API_KEY || "",
  openaiModel: process.env.OPENAI_MODEL || "gpt-4.1-mini",

  mockCommerce: String(process.env.MOCK_COMMERCE || "true") === "true",
  dlavieApiBaseUrl: process.env.DLAVIE_API_BASE_URL || "",
  dlavieApiToken: process.env.DLAVIE_API_TOKEN || "",
  checkoutBaseUrl: process.env.CHECKOUT_BASE_URL || "",

  adminToken: process.env.ADMIN_TOKEN || ""
};

export function validateEnv() {
  if (env.nodeEnv !== "production") return;

  const missing = requiredInProduction.filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Missing required production env vars: ${missing.join(", ")}`);
  }
}
